# -*- coding: utf-8 -*-
__all__ = ["Normalizer", "getInstance"]
from .core import Normalizer, getInstance
